package ca.sheridancollege.dobariyz.beans;

public enum Roles {

	USER,ADMIN;
}
