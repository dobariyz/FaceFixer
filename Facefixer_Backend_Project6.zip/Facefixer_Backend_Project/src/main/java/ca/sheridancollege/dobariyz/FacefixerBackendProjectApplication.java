package ca.sheridancollege.dobariyz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacefixerBackendProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacefixerBackendProjectApplication.class, args);
	}

}
