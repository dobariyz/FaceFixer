package ca.sheridancollege.dobariyz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacefixerBackendProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
